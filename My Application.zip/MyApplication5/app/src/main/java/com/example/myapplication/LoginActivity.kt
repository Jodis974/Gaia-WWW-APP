package com.example.myapplication

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class LoginActivity : AppCompatActivity() {
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        initializeUI()
        checkPreviousLogin()
    }

    private fun initializeUI() {
        emailEditText = findViewById(R.id.login_email)
        passwordEditText = findViewById(R.id.login_password)
        val loginButton = findViewById<Button>(R.id.login_button)
        loginButton.setOnClickListener { attemptLogin() }
    }

    private fun checkPreviousLogin() {
        val prefs = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val email = prefs.getString("Nom", null)
        val password = prefs.getString("NumClient", null)

        if (email != null && password != null) {
            validateCredentials(email, password, isAutoLogin = true)
        }
    }

    private fun attemptLogin() {
        val email = emailEditText.text.toString().trim()
        val password = passwordEditText.text.toString().trim()

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Les champs ne peuvent pas être vides", Toast.LENGTH_SHORT).show()
            return
        }

        validateCredentials(email, password, isAutoLogin = false)
    }

    private fun validateCredentials(email: String, password: String, isAutoLogin: Boolean) {
        val queue = Volley.newRequestQueue(this)
        val url = "http://10.0.2.2:9200/login"  // Ensure this URL is correct for your server setup
        val jsonBody = JSONObject().apply {
            put("Nom", email)
            put("numClient", password)
        }

        val jsonObjectRequest = JsonObjectRequest(Request.Method.POST, url, jsonBody,
            Response.Listener { response ->
                if (response.getBoolean("status")) {
                    val userData = response.getJSONObject("data")
                    updateLocalUserData(userData)
                    navigateToDataActivity()
                } else {
                    handleLoginFailure(isAutoLogin, response.getString("message"))
                }
            },
            Response.ErrorListener { error ->
                Toast.makeText(this, "Login failed due to network error: ${error.message}", Toast.LENGTH_SHORT).show()
                Log.e("LoginActivity", "Network error on login attempt: ${error.message}")
            })

        queue.add(jsonObjectRequest)
    }

    private fun updateLocalUserData(userData: JSONObject) {
        val userObject = userData.getJSONObject("utilisateur") // Assuming 'utilisateur' contains the user data

        getSharedPreferences("UserPrefs", Context.MODE_PRIVATE).edit().apply {
            putString("IdUtilisateur", userObject.optString("IdUtilisateur"))
            putString("Nom", userObject.optString("Nom"))
            putString("Prenom", userObject.optString("Prenom"))
            putString("Age", userObject.optString("Age"))
            putString("Adresse", userObject.optString("Adresse"))
            putString("NumClient", userObject.optString("NumClient"))
            apply()
        }
    }

    private fun handleLoginFailure(isAutoLogin: Boolean, message: String) {
        if (isAutoLogin) {
            Toast.makeText(this, "Session expired, please log in again.", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        }
    }

    private fun navigateToDataActivity() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
