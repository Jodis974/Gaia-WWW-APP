package com.example.myapplication

import android.annotation.SuppressLint
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.RemoteViews
import org.json.JSONObject

class GaiaWidget : AppWidgetProvider() {

    companion object {
        const val UPDATE_ACTION = "com.example.myapplication.action.UPDATE_WIDGET"
        private val numberToWord = mapOf(
            1 to "One",
            2 to "Two",
            3 to "Three",
            4 to "Four",
            5 to "Five"
        )
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == UPDATE_ACTION) {
            val dataString = intent.getStringExtra("data")
            Log.d("GaiaWidget", "onReceive data: $dataString")
            if (dataString != null) {
                val data = JSONObject(dataString)
                val appWidgetManager = AppWidgetManager.getInstance(context)
                val thisAppWidget = ComponentName(context.packageName, GaiaWidget::class.java.name)
                val appWidgetIds = appWidgetManager.getAppWidgetIds(thisAppWidget)
                appWidgetIds.forEach { appWidgetId ->
                    updateAppWidget(context, appWidgetManager, appWidgetId, data)
                }
            }
        }
    }

    @SuppressLint("DiscouragedApi")
    private fun updateAppWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, data: JSONObject) {
        val views = RemoteViews(context.packageName, R.layout.gaia_widget)
        for (i in 1..5) {
            val categoryKey = "Category$i"
            val numberWord = numberToWord[i] ?: continue
            if (data.has(categoryKey)) {
                val category = data.getJSONObject(categoryKey)
                Log.d("GaiaWidget", "Updating view $numberWord with data: $category")

                views.setTextViewText(context.resources.getIdentifier("Date$numberWord", "id", context.packageName), category.getString("Date"))
                views.setTextViewText(context.resources.getIdentifier("Capacity$numberWord", "id", context.packageName), category.getString("Capacity"))
                views.setTextViewText(context.resources.getIdentifier("Power$numberWord", "id", context.packageName), category.getString("Consumption"))
                views.setTextViewText(context.resources.getIdentifier("InverterPower$numberWord", "id", context.packageName), category.getString("InverterPower"))
                views.setTextViewText(context.resources.getIdentifier("PowerProfit$numberWord", "id", context.packageName), category.getString("PowerProfit"))
                views.setTextViewText(context.resources.getIdentifier("ReductionCoal$numberWord", "id", context.packageName), category.getString("ReductionCoal"))
                views.setTextViewText(context.resources.getIdentifier("PowerRatio$numberWord", "id", context.packageName), category.getString("PowerRatio"))
                views.setTextViewText(context.resources.getIdentifier("ReductionCoDeux$numberWord", "id", context.packageName), category.getString("ReductionCO2"))
                views.setTextViewText(context.resources.getIdentifier("GridPower$numberWord", "id", context.packageName), category.getString("GridPower"))
            }
        }
        appWidgetManager.updateAppWidget(appWidgetId, views)
    }
}
