package com.example.myapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Outline
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {
    private lateinit var bottomNavigationView: BottomNavigationView
    private lateinit var frameLayout: FrameLayout











    private lateinit var tceamTextView: TextView
    private lateinit var tceambTextView: TextView
    private lateinit var tceavTextView: TextView

    private var selectedLayoutId: Int? = null





    private val handler = Handler()
    private val updateInterval: Long = 30000 // 1 seconde
    private val updateIntervalDeux: Long = 30000 // 1 seconde

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val imageView = findViewById<ImageView>(R.id.image_view_profile)
        imageView.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                val diameter = Math.min(view.width, view.height)
                outline.setOval(0, 0, diameter, diameter)
            }
        }
        imageView.clipToOutline = true
        val layouts = listOf(
            R.id.layout_battery,
            R.id.layout_network,
            R.id.layout_charger
        )
        layouts.forEach { layoutId ->
            val layout = findViewById<ConstraintLayout>(layoutId)
            layout.setOnClickListener {
                toggleBackground(layoutId)
            }
        }

        tceamTextView = findViewById(R.id.batteryValue)
        tceambTextView = findViewById(R.id.networkValue)
        tceavTextView = findViewById(R.id.chargerValue)




        fetchData()
        fetchDataDeux()
        fetchDataTrois()


        handler.postDelayed(object : Runnable {
            override fun run() {
                fetchData()
                handler.postDelayed(this, updateInterval)
            }
        }, updateInterval)

        handler.postDelayed(object : Runnable {
            override fun run() {
                fetchDataDeux()
                fetchDataTrois()

                handler.postDelayed(this, updateIntervalDeux)
            }
        }, updateIntervalDeux)







        bottomNavigationView = findViewById(R.id.bottomNavView)
        frameLayout = findViewById(R.id.frameLayout)
        bottomNavigationView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navDashboard -> {
                    loadFragment(HomeFragment(), false)
                }
                R.id.navEnergyUsage -> {
                    loadFragment(SearchFragment(), false)
                }
                R.id.navSavings -> {
                    loadFragment(ProfileFragment(), false)
                }
            }
            true
        }
        loadFragment(HomeFragment(), true)





    }
    private fun loadFragment(fragment: Fragment, isAppInitialized: Boolean) {
        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()
        if (isAppInitialized) {
            fragmentTransaction.add(R.id.frameLayout, fragment)
        } else {
            fragmentTransaction.replace(R.id.frameLayout, fragment)
        }
        fragmentTransaction.commit()
    }

    private fun toggleBackground(layoutId: Int) {
        val newLayout = findViewById<ConstraintLayout>(layoutId)
        val currentLayout = selectedLayoutId?.let { findViewById<ConstraintLayout>(it) }

        if (selectedLayoutId == layoutId) {
            newLayout.background = ContextCompat.getDrawable(this, R.drawable.rounded_corner_white_background)
            selectedLayoutId = null
        } else {
            currentLayout?.background = ContextCompat.getDrawable(this, R.drawable.rounded_corner_white_background)
            newLayout.background = ContextCompat.getDrawable(this, R.drawable.rounded_corner_background)
            selectedLayoutId = layoutId
        }
    }




    @SuppressLint("SetTextI18n")
    private fun fetchData() {
        val queue = Volley.newRequestQueue(this)
        val url = "http://10.0.2.2:9200/api/data"

        val jsonObjectRequest = JsonObjectRequest(Request.Method.GET, url, null,
            { response ->
                tceamTextView.text = response.optJSONObject("TCEAM")?.getString("value") ?: "Erreur"
                tceambTextView.text = response.optJSONObject("TCEAMB")?.getString("value") ?: "Erreur"
                tceavTextView.text = response.optJSONObject("TCEAV")?.getString("value") ?: "Erreur"
            },
            { error ->
                Log.e("MainActivity", "Error fetching data", error)
                tceamTextView.text = "Erreur"
                tceambTextView.text = "Erreur"
                tceavTextView.text = "Erreur"
            })

        queue.add(jsonObjectRequest)
    }




    private fun fetchDataDeux() {
        val queue = Volley.newRequestQueue(this)
        val url = "http://10.0.2.2:9200/datas"

        val jsonObjectRequest = JsonObjectRequest(Request.Method.GET, url, null,
            { response ->
                Log.d("MainActivityDeux", "fetchDataDeux response: $response")
                sendUpdateBroadcast(response.toString())
            },
            { error ->
                Log.e("MainActivityDeux", "Error fetching dataDeux", error)
            })

        queue.add(jsonObjectRequest)
    }
    private fun sendUpdateBroadcast(data: String) {
        val intent = Intent(this, GaiaWidget::class.java).also { intent ->
            intent.action = GaiaWidget.UPDATE_ACTION
            intent.putExtra("data", data)
            sendBroadcast(intent)
        }
    }




    private fun fetchDataTrois() {
        val queue = Volley.newRequestQueue(this)
        val url = "http://10.0.2.2:9200/datas"

        val jsonObjectRequest = JsonObjectRequest(Request.Method.GET, url, null,
            { response ->
                Log.d("MainActivityDeux", "fetchDataTrois response: $response")
                SharedData.updateData(response.toString())
            },
            { error ->
                Log.e("MainActivityDeux", "Error fetching DataTrois", error)
            })

        queue.add(jsonObjectRequest)
    }






    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }


}