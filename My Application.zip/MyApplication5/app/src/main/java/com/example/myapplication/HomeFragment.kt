package com.example.myapplication

import android.content.Context
import android.graphics.Color
import android.icu.text.SimpleDateFormat
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import org.json.JSONObject
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.formatter.ValueFormatter
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet
import java.util.Date
import java.util.Locale


class HomeFragment : Fragment() {
    private lateinit var autoCompleteTextView: AutoCompleteTextView
    private lateinit var adapterItems: ArrayAdapter<String>
    private var dateToDataMap = mutableMapOf<String, JSONObject>()
    private lateinit var lineChartConsumption: LineChart
    private lateinit var lineChartCapacity: LineChart
    private lateinit var lineChartGridPower: LineChart
    private lateinit var lineChartInverterPower: LineChart
    private lateinit var nomPrenomClient: TextView

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        autoCompleteTextView = view.findViewById(R.id.auto_complete_txt)
        nomPrenomClient = view.findViewById(R.id.nom_prenom_ClientHome)
        updateUserData()

        adapterItems = ArrayAdapter(requireContext(), R.layout.list_item, arrayListOf())
        autoCompleteTextView.setAdapter(adapterItems)

        setupAutoCompleteTextViewListener()

        return view
    }
    private fun updateUserData() {
        val prefs = requireActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val nom = prefs.getString("Nom", "Inconnu")
        val prenom = prefs.getString("Prenom", "")

        nomPrenomClient.text = "$prenom $nom"
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        lineChartConsumption = view.findViewById(R.id.chart_consumption)
        lineChartCapacity = view.findViewById(R.id.chart_capacity)
        lineChartGridPower = view.findViewById(R.id.chart_gridpower)


        SharedData.data.observe(viewLifecycleOwner, Observer { dataString ->
            updateAutoCompleteTextView(dataString)
            setupChartConsumption()
            setupChartCapacity()
            setupChartGridPower()






        })
    }


    private fun updateAutoCompleteTextView(dataString: String) {
        try {
            val jsonObject = JSONObject(dataString)
            dateToDataMap.clear()
            val dates = mutableListOf<String>()
            for (key in jsonObject.keys()) {
                jsonObject.optJSONObject(key)?.let { category ->
                    val date = category.optString("Date", "No Date")
                    dates.add(date)
                    dateToDataMap[date] = category
                }
            }

            adapterItems.clear()
            adapterItems.addAll(dates)
            adapterItems.notifyDataSetChanged()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    private fun setupAutoCompleteTextViewListener() {
        autoCompleteTextView.setOnItemClickListener { _, _, position, _ ->
            val selectedDate = adapterItems.getItem(position)
            selectedDate?.let {
                dateToDataMap[selectedDate]?.let { data ->
                    displayDataForDate(data)
                }
            }
        }
    }


    private fun displayDataForDate(data: JSONObject) {
        view?.findViewById<TextView>(R.id.jourHome)?.text = data.optString("Date", "No Data")
        view?.findViewById<TextView>(R.id.CapacityHome)?.text = data.optString("Capacity", "No Data")
        view?.findViewById<TextView>(R.id.PowerHome)?.text = data.optString("Consumption", "No Data")
        view?.findViewById<TextView>(R.id.InverterPowerHome)?.text = data.optString("InverterPower", "No Data")
        view?.findViewById<TextView>(R.id.PowerProfitHome)?.text = data.optString("PowerProfit", "No Data")
        view?.findViewById<TextView>(R.id.ReductionCoalHome)?.text = data.optString("ReductionCoal", "No Data")
        view?.findViewById<TextView>(R.id.PowerRationHome)?.text = data.optString("PowerRatio", "No Data")
        view?.findViewById<TextView>(R.id.ReductionCoDeuxHome)?.text = data.optString("ReductionCO2", "No Data")
        view?.findViewById<TextView>(R.id.GridPowerHome)?.text = data.optString("GridPower", "No Data")

    }






    private fun setupChartConsumption() {
        val entries = mutableListOf<Entry>()
        val dateFormat = SimpleDateFormat("dd MMM", Locale.getDefault())

        val sortedEntries = dateToDataMap.values.sortedBy {
            dateFormat.parse(it.optString("Date", "01 Jan"))
        }

        sortedEntries.forEachIndexed { index, data ->
            val date = dateFormat.parse(data.optString("Date", "01 Jan")) ?: return
            val consumption = data.optDouble("Consumption", 0.0).toFloat()
            entries.add(Entry(index.toFloat(), consumption, data.optString("Date")))
        }

        val dataSet = LineDataSet(entries, "Consommation").apply {
            color = Color.BLUE
            setDrawFilled(true)
            fillColor = Color.BLUE
            fillAlpha = 100
            setDrawCircles(true)
            setCircleColor(Color.BLUE)
            lineWidth = 2f
            valueTextColor = Color.BLACK
            valueTextSize = 6f
            setDrawValues(true)
            valueFormatter = object : ValueFormatter() {
                override fun getPointLabel(entry: Entry): String {
                    val date = entry.data as String
                    return "\n${entry.y}"
                }
            }
        }

        lineChartConsumption.apply {
            data = LineData(dataSet)
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                valueFormatter = IndexAxisValueFormatter(sortedEntries.map { it.optString("Date") })
                setLabelCount(5, true)
                textSize = 10f
                granularity = 1f
                isGranularityEnabled = true
            }
            axisRight.isEnabled = false
            axisLeft.axisMinimum = 0f
            description.isEnabled = false
            legend.form = Legend.LegendForm.SQUARE
            legend.textSize = 12f
            invalidate()
        }
    }




    private fun setupChartCapacity() {
        val entries = mutableListOf<Entry>()
        val dateFormat = SimpleDateFormat("dd MMM", Locale.getDefault())

        val sortedEntries = dateToDataMap.values.sortedBy {
            dateFormat.parse(it.optString("Date", "01 Jan"))
        }

        sortedEntries.forEachIndexed { index, data ->
            val date = dateFormat.parse(data.optString("Date", "01 Jan")) ?: return
            val consumption = data.optDouble("Capacity", 0.0).toFloat()
            entries.add(Entry(index.toFloat(), consumption, data.optString("Date")))
        }

        val dataSet = LineDataSet(entries, "Capacité").apply {
            color = Color.GREEN
            setDrawFilled(true)
            fillColor = Color.GREEN
            fillAlpha = 100
            setDrawCircles(true)
            setCircleColor(Color.GREEN)
            lineWidth = 2f
            valueTextColor = Color.BLACK
            valueTextSize = 6f
            setDrawValues(true)
            valueFormatter = object : ValueFormatter() {
                override fun getPointLabel(entry: Entry): String {
                    val date = entry.data as String
                    return "\n${entry.y}"
                }
            }
        }

        lineChartCapacity.apply {
            data = LineData(dataSet)
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                valueFormatter = IndexAxisValueFormatter(sortedEntries.map { it.optString("Date") })
                setLabelCount(5, true)
                textSize = 10f
                granularity = 1f
                isGranularityEnabled = true
            }
            axisRight.isEnabled = false
            axisLeft.axisMinimum = 0f
            description.isEnabled = false
            legend.form = Legend.LegendForm.SQUARE
            legend.textSize = 12f
            invalidate()
        }
    }





    private fun setupChartGridPower() {
        val entries = mutableListOf<Entry>()
        val dateFormat = SimpleDateFormat("dd MMM", Locale.getDefault())

        val sortedEntries = dateToDataMap.values.sortedBy {
            dateFormat.parse(it.optString("Date", "01 Jan"))
        }

        sortedEntries.forEachIndexed { index, data ->
            val date = dateFormat.parse(data.optString("Date", "01 Jan")) ?: return
            val consumption = data.optDouble("GridPower", 0.0).toFloat()
            entries.add(Entry(index.toFloat(), consumption, data.optString("Date")))
        }

        val dataSet = LineDataSet(entries, "Réseau électrique").apply {
            color = Color.RED
            setDrawFilled(true)
            fillColor = Color.RED
            fillAlpha = 100
            setDrawCircles(true)
            setCircleColor(Color.RED)
            lineWidth = 2f
            valueTextColor = Color.BLACK
            valueTextSize = 6f
            setDrawValues(true)
            valueFormatter = object : ValueFormatter() {
                override fun getPointLabel(entry: Entry): String {
                    val date = entry.data as String
                    return "\n${entry.y}"
                }
            }
        }

        lineChartGridPower.apply {
            data = LineData(dataSet)
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                valueFormatter = IndexAxisValueFormatter(sortedEntries.map { it.optString("Date") })
                setLabelCount(5, true)
                textSize = 10f
                granularity = 1f
                isGranularityEnabled = true
            }
            axisRight.isEnabled = false
            axisLeft.axisMinimum = 0f
            description.isEnabled = false
            legend.form = Legend.LegendForm.SQUARE
            legend.textSize = 12f
            invalidate()
        }
    }


}